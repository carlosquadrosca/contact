export default function App() {
  return <h1>Client Manager</h1>;
}